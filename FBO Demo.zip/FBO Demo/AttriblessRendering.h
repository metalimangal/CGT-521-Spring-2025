#pragma once

void draw_attribless_triangle_grid(int nx, int ny);
void draw_attribless_particles(int n);
void draw_attribless_cube();
void draw_attribless_quad();
void bind_attribless_vao();
